#include <stdio.h>

int main() {
  int a=5,b=7;

  if (a<b) {
    printf("a is smaller than b\n");
    printf("because a is %d and b is %d\n",a,b);
  }
  else {
    printf("a is bigger than b\n");
    printf("because a is %d and b is %d\n",a,b);
  }
}
