#include <stdio.h>
void main() {
  int a=5,b=3,plus,minus,mult,div;
  plus  = a+b;
  minus = a-b;
  mult  = a*b;
  div  = a/b;
  printf("Results: plus: %d, minus: %d, mult: %d, div: %d\n",
	 plus,minus,mult,div);
}
